#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

#include <vector>
size_t insertionCount{0};
//every number seen as far will be sorted
//efficient O(N^2) sorting algorithm for small N
//good at almost sorted lists
template<typename T>
void insertionSort(std::vector<T> &array, size_t left, size_t right)
{
    size_t j;
    for (size_t i = left+1; i < right+1; i++)
    {
        T tmp = array [i];
        for (j = i; j > 0 && tmp < array[j-1]; j--){
            array[j] = array[j-1];
            insertionCount++;
        }
        array[j] = tmp;
    }
}
#endif // INSERTIONSORT_H
