#ifndef HEAPSORT_H
#define HEAPSORT_H
#include <vector>

size_t heapCount{0};

// use inline to reduce function call overhead for small function
//function returns left child of index
inline int getLeftChild(int index){
    return 2*index+1;
}

//percolate down the heap, where the hole is where to begin from
template<typename T>
void percolateDown(std::vector<T> &array, int hole, int size)
{
    int child;
    T tmp = std::move( array[ hole ] );

    for( ; getLeftChild(hole) < size; hole = child )
    {
        heapCount++;
        child = getLeftChild(hole);
        if( child != size-1 && array[ child] < array[ child+1 ] )
            ++child;
        //compare array child with tmp to see if it fulfills the maxHeap
        if( array[ child ] > tmp )
            array[ hole ] = std::move( array[ child ] );
        else
            break;
    }
    array[ hole ] = std::move( tmp );
}

//build heap with time complexity of O(N)
template<typename T1>
void buildHeap(std::vector<T1> &array)
{
    //call percolate down for all nodes under the root starting
    //with the rightmost which is not a leaf
    for( int i = array.size()/2-1; i >= 0; --i ){
        heapCount++;
        percolateDown(array,i,array.size());
    }
}
//remove the max item and place it in last element
template<typename T2>
void deleteMax(std::vector<T2> &array, int maxItem){
    std::swap(array[0], array[maxItem]);
    percolateDown(array,0,maxItem);
}

//heapsort in increasing order
template <typename T3>
void heapSort(std::vector<T3> &array){
    //first use build heap O(N)
    buildHeap(array);
    //use deleteMax on every node, and keep decreasing the "size"
    for (int j=array.size()-1;j>0;--j) {
        deleteMax(array,j);
    }
}



#endif // HEAPSORT_H
