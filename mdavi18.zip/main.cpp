#include <iostream>
#include "quickselect.h"
#include "heapsort.h"
#include <time.h>
#include <cmath>

using namespace std;

int main()
{
    size_t numElems {100}, nTimesDouble{10},iterations{10}, operationCount{0}, heapOperationCount{0};
    size_t k{2}, numRange{numElems*2};
    double avgOperationCount{0}, avgHeapOperationCount{0};
    std::vector<size_t> n,nLogN, nActual, nHeapActual;

    srand (time(NULL));
    //for loop for doubling the size of array for each experiment
    for (size_t i =0; i < nTimesDouble;i++) {
        if(i>0)
            numElems=numElems*2;
        //create array for quickSelect
        std::vector<int> a(numElems);
        n.push_back(a.size());
        nLogN.push_back(log2(a.size())*a.size());
        //nSquared.push_back(pow(a.size(),2));
        std::cout << "size of array: " << a.size() << " thus this will be about the same as "
                                                      "the time complexity." << std::endl;
        for (size_t j = 0;j<iterations;j++) {
            for (size_t i = 0; i < a.size();i++) {
                int randNum = rand() % numRange;
                a[i]=(randNum);
            }
            //create a copy of the array for quickSelect
            //this will be used for heapSort
            std::vector<int> b=a;
            //only show array if under certain size and number iterations
            if(a.size()<30 && iterations <= 5){
                std::cout << "before search: ";
                print(a);
            }
            heapSort(b);
            quickSelect(a,k);
            if(a.size()<30 && iterations <=5){
                std::cout << "after search:";
                print(a);
                std::cout << "k'th smallest element: "<< a[k] << " with k: " << k << std::endl;
                std::cout << "k'th smallest element: "<< b[k] << " with k: " << k << std::endl;
            }
            operationCount+=count;
            heapOperationCount+=heapCount;
            std::cout << "iterations for this try number " << j+1 << ": " << count <<std::endl;
            //reset counters here, because of recursive calls in quickselect
            count=0;
            insertionCount=0;
            heapCount=0;
        }
        avgOperationCount = operationCount/iterations;
        avgHeapOperationCount =heapOperationCount/iterations;
        nActual.push_back(avgOperationCount);
        nHeapActual.push_back(avgHeapOperationCount);
        //reset counters
        avgOperationCount=0;
        operationCount=0;
        heapOperationCount=0;
        avgHeapOperationCount;
    }
    std::cout << "N = ";
    print(n);
    std::cout << "NLogN = ";
    print(nLogN);
    std::cout << "NHeapCounted = ";
    print(nHeapActual);
    std::cout << "NCounted = ";
    print(nActual);

    return 0;
}
