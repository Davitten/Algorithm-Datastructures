#ifndef QUICKSELECT_H
#define QUICKSELECT_H
#include <vector>
#include <iostream>
#include "insertionsort.h"

size_t count{0};

template <typename t>
void print(std::vector<t>& array){
    std::cout << "[";
    for (size_t i =0;i<array.size();i++) {
        std::cout << array[i];
        if(i<array.size()-1)
            std::cout << ", ";
    }
    std::cout << "]" << std::endl;
}

//function to get median of 3 numbers in an array
//more specific from the first, center and last element
template <typename comparable>
const comparable &median3(std::vector<comparable>& container, size_t left, size_t right){
    //find center
    size_t center = (left + right ) / 2;
    //if the center value is less than left swap
    if( container[center] < container[left] ){
        std::swap( container[left], container[center] );
    }
    //check if right value is less than the old/new left value
    if( container[right] < container[left] ){
        std::swap( container[left], container[right] );
    }
    //check if old/new right value is less than center
    if( container[right] < container[center] ){
        std::swap( container[ center ], container[ right ] );
    }
    //now sorted so min is left median is center and max is highest right
    //now swap median to second last index
    std::swap(container[center], container[right - 1]);

    return container[right - 1];
}
//quickSelect function, places k'th lowest element in k'th element
template<typename T>
void quickSelect(std::vector<T> &container,size_t left, size_t right, size_t k){
    //cutoff to save time with insertionsort
    const int CUTOFF = 10;
    if(left+CUTOFF <= right){
        //calculate pivot and place it at right-1
        const T& pivot = median3(container,left,right);
        size_t i = left, j=right-1;
        for (;;) {
            //skip elements that are smaller than pivot,
            //i will point at element placed on wrong side of pivot
            while (container[++i]<pivot) {
                count++;
            }
            //skip elements that are bigger than pivot from one left of pivot [right-1]
            //j will point at element placed on wrong side of pivot
            while (pivot < container[--j]) {
                count++;
            }

            //run the for loop while i is to the left of j
            if(i<j){
                std::swap(container[i],container[j]);
            }
            else {
                break;
            }
        }
        //swap pivot to where for loop ended
        std::swap(container[i],container[right-1]);
        //the container is divided in two with all elements to the left of i is smaller than pivot
        //and every element to the right of i is bigger than the pivot
        if(k<=i){
            //search in the small elements
            quickSelect(container,left,i-1,k);
        }
        else if (k>i+1) {
            //search in the big elements
            quickSelect(container,i+1,right,k);
        }
    }
    else {
        insertionSort(container,left,right);
        count+=insertionCount;
    }
}
//driver function
template<typename U>
void quickSelect(std::vector<U> &container,size_t k){
    quickSelect(container,0,container.size()-1, k);
}

#endif // QUICKSELECT_H


